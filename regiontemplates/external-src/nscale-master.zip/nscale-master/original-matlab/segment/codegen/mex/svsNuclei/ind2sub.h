/*
 * ind2sub.h
 *
 * Code generation for function 'ind2sub'
 *
 * C source code generated on: Tue Jun 21 16:24:31 2011
 *
 */

#ifndef __IND2SUB_H__
#define __IND2SUB_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blascompat32.h"
#include "rtwtypes.h"
#include "svsNuclei_types.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern void ind2sub(const emxArray_real_T *ndx, emxArray_real_T *varargout_1, emxArray_real_T *varargout_2);
#endif
/* End of code generation (ind2sub.h) */
