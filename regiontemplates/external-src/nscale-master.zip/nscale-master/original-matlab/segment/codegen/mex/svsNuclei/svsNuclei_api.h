/*
 * svsNuclei_api.h
 *
 * Code generation for function 'svsNuclei_api'
 *
 * C source code generated on: Tue Jun 21 16:24:31 2011
 *
 */

#ifndef __SVSNUCLEI_API_H__
#define __SVSNUCLEI_API_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blascompat32.h"
#include "rtwtypes.h"
#include "svsNuclei_types.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern void svsNuclei_api(svsNucleiStackData *SD, const mxArray * const prhs[3]);
#endif
/* End of code generation (svsNuclei_api.h) */
