/*
 * svsNuclei.h
 *
 * Code generation for function 'svsNuclei'
 *
 * C source code generated on: Tue Jun 21 16:24:31 2011
 *
 */

#ifndef __SVSNUCLEI_H__
#define __SVSNUCLEI_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blascompat32.h"
#include "rtwtypes.h"
#include "svsNuclei_types.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern void svsNuclei(svsNucleiStackData *SD, const emxArray_char_T *impath, const emxArray_char_T *filename, const emxArray_char_T *resultpath);
#endif
/* End of code generation (svsNuclei.h) */
