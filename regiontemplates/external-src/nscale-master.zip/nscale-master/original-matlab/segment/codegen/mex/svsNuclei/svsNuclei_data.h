/*
 * svsNuclei_data.h
 *
 * Code generation for function 'svsNuclei_data'
 *
 * C source code generated on: Tue Jun 21 16:24:30 2011
 *
 */

#ifndef __SVSNUCLEI_DATA_H__
#define __SVSNUCLEI_DATA_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blascompat32.h"
#include "rtwtypes.h"
#include "svsNuclei_types.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */
extern emlrtRSInfo m_emlrtRSI;
extern emlrtRSInfo ob_emlrtRSI;
extern emlrtMCInfo h_emlrtMCI;
extern svsNucleiStackData *svsNucleiStackDataLocal;

/* Variable Definitions */

/* Function Declarations */
#endif
/* End of code generation (svsNuclei_data.h) */
