/*
 * svsNuclei_initialize.c
 *
 * Code generation for function 'svsNuclei_initialize'
 *
 * C source code generated on: Tue Jun 21 16:24:31 2011
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "svsNuclei.h"
#include "svsNuclei_initialize.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */

/* Function Definitions */

void svsNuclei_initialize(emlrtContext *context)
{
    emlrtEnterRtStack(&emlrtContextGlobal);
    emlrtFirstTime(context);
}
/* End of code generation (svsNuclei_initialize.c) */
