/*
 * svsNuclei_mexutil.h
 *
 * Code generation for function 'svsNuclei_mexutil'
 *
 * C source code generated on: Tue Jun 21 16:24:30 2011
 *
 */

#ifndef __SVSNUCLEI_MEXUTIL_H__
#define __SVSNUCLEI_MEXUTIL_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blascompat32.h"
#include "rtwtypes.h"
#include "svsNuclei_types.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern void error(const mxArray *b, emlrtMCInfo *location);
#endif
/* End of code generation (svsNuclei_mexutil.h) */
