/*
 * svsNuclei_data.c
 *
 * Code generation for function 'svsNuclei_data'
 *
 * C source code generated on: Tue Jun 21 16:24:30 2011
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "svsNuclei.h"
#include "svsNuclei_data.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
emlrtRSInfo m_emlrtRSI = { 211, "find", "/usr/local/MATLAB/R2011a/toolbox/eml/lib/matlab/elmat/find.m" };
emlrtRSInfo ob_emlrtRSI = { 30, "eml_isequal_core", "/usr/local/MATLAB/R2011a/toolbox/eml/lib/matlab/eml/eml_isequal_core.m" };
emlrtMCInfo h_emlrtMCI = { 211, 9, "find", "/usr/local/MATLAB/R2011a/toolbox/eml/lib/matlab/elmat/find.m" };
svsNucleiStackData *svsNucleiStackDataLocal;

/* Function Declarations */

/* Function Definitions */
/* End of code generation (svsNuclei_data.c) */
