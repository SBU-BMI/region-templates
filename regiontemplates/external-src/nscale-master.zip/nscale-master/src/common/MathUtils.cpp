/*
 * MathUtils.cpp
 *
 *  Created on: Jan 11, 2013
 *      Author: tcpan
 */

#include "MathUtils.h"

namespace cci {
namespace common {

double MathUtils::spare = 0;
bool MathUtils::spareready = false;


} /* namespace common */
} /* namespace cci */
