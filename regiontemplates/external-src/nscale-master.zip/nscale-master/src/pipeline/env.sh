export NSCALE_HOME=/home/tcpan/PhD/path/src/nscale
export LD_LIBRARY_PATH=${NSCALE_HOME}/src/segment:${NSCALE_HOME}/src/features-cpu:${NSCALE_HOME}/src/features/execEngine:/home/tcpan/PhD/path/ext/hdf5-1.8.7-linux-x86_64-shared/lib:${LD_LIBRARY_PATH}
