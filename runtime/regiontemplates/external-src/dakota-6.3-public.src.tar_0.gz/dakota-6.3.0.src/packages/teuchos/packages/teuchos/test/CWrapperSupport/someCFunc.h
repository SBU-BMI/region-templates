
#ifdef __cplusplus
extern "C" {
#endif

int someCFunc(int input, int *ierr);

#ifdef __cplusplus
} // extern "C"
#endif
