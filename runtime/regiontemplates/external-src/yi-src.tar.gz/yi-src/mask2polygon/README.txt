OpenCV 3.0.0 is required.
Boost 1.58.0 is required if polygon_edit is to be used.
