#ifndef utilityScalarImage_h_
#define utilityScalarImage_h_

// itk
#include "itkOtsuThresholdImageFilter.h"
#include "itkCastImageFilter.h"
#include "itkBinaryBallStructuringElement.h"
#include "itkBinaryErodeImageFilter.h"

// local
#include "itkTypedefs.h"


namespace ImagenomicAnalytics
{
  namespace ScalarImage
  {
    template< typename ImageType >
    bool isImageAllZero(ImageType* image)
    {
      std::size_t numPixels = image->GetLargestPossibleRegion().GetNumberOfPixels();

      typename ImageType::PixelType z = itk::NumericTraits<typename ImageType::PixelType>::ZeroValue();

      /// Check if the current mask is all zero
      bool imageIsAllZero = true;
      const typename ImageType::PixelType* imageBufferPointer = image->GetBufferPointer();
      for (std::size_t it = 0; it < numPixels; ++it)
        {
          if (imageBufferPointer[it] != z)
            {
              imageIsAllZero = false;
              break;
            }
        }

      return imageIsAllZero;
    }
    template< typename TNull >
    itkUCharImageType::Pointer otsuThresholdImage(itkFloatImageType::Pointer image, itkUCharImageType::PixelType maskValue, float otsuRatio = 1.0)
    {
      typedef itk::OtsuThresholdImageFilter<itkFloatImageType, itkUCharImageType> FilterType;
      FilterType::Pointer otsuFilter = FilterType::New();
      otsuFilter->SetInput(image);
      otsuFilter->SetInsideValue(maskValue);
      otsuFilter->Update();

      itkUCharImageType::Pointer mask = otsuFilter->GetOutput();

      itkFloatImageType::PixelType otsuThld = otsuRatio*(otsuFilter->GetThreshold());

      const itkFloatImageType::PixelType* imageBufferPointer = image->GetBufferPointer();
      itkUCharImageType::PixelType* maskBufferPointer = mask->GetBufferPointer();
      long numPixels = mask->GetLargestPossibleRegion().GetNumberOfPixels();
      for (long it = 0; it < numPixels; ++it)
        {
          maskBufferPointer[it] = imageBufferPointer[it]<=otsuThld?maskValue:0;
        }

      return mask;
    }


    template< typename InputImageType, typename OutputImageType >
    typename OutputImageType::Pointer
    castItkImage( const InputImageType* inputImage )
    {
      typedef itk::CastImageFilter< InputImageType, OutputImageType > itkCastFilter_t;

      typename itkCastFilter_t::Pointer caster = itkCastFilter_t::New();
      caster->SetInput( inputImage );
      caster->Update();

      return caster->GetOutput();
    }


    template< typename TNull >
    itkUCharImageType::Pointer edgesOfDifferentLabelRegion(itkUIntImageType::Pointer labelImage)
    {
      typedef itk::GradientMagnitudeImageFilter<itkUIntImageType, itkFloatImageType >  GradientMagnitudeImageFilterType;
      GradientMagnitudeImageFilterType::Pointer gradientMagnitudeImageFilter = GradientMagnitudeImageFilterType::New();
      gradientMagnitudeImageFilter->SetInput(labelImage);
      gradientMagnitudeImageFilter->Update();

      itkFloatImageType::Pointer gradImage = gradientMagnitudeImageFilter->GetOutput();
      itkFloatImageType::PixelType* gradImageBufferPointer = gradImage->GetBufferPointer();

      itkUCharImageType::Pointer mask = itkUCharImageType::New();
      mask->SetRegions( gradImage->GetLargestPossibleRegion() );
      mask->Allocate();
      mask->FillBuffer(0);

      itkUCharImageType::PixelType* maskBufferPointer = mask->GetBufferPointer();

      long numPixels = mask->GetLargestPossibleRegion().GetNumberOfPixels();

      for (long it = 0; it < numPixels; ++it)
        {
          if (gradImageBufferPointer[it] >= 0.5)
            {
              maskBufferPointer[it] = 1;
            }
        }


      return mask;
    }


    template< typename TNull >
    itkRGBImageType::Pointer generateSegmentationOverlay(itkRGBImageType::Pointer img, itkUCharImageType::Pointer binaryMask)
    {
      /// Compute the boundary of the mask by erode
      typedef itk::BinaryBallStructuringElement< itkUCharImageType::PixelType, itkUCharImageType::ImageDimension> StructuringElementType;
      StructuringElementType structuringElement;
      int radius = 1;
      structuringElement.SetRadius(radius);
      structuringElement.CreateStructuringElement();

      typedef itk::BinaryErodeImageFilter<itkUCharImageType, itkUCharImageType, StructuringElementType> BinaryErodeImageFilterType;
      BinaryErodeImageFilterType::Pointer erodeFilter = BinaryErodeImageFilterType::New();
      erodeFilter->SetInput(binaryMask);
      erodeFilter->SetErodeValue(1);
      erodeFilter->SetKernel(structuringElement);
      erodeFilter->Update();
      itkUCharImageType::Pointer erodeMask = erodeFilter->GetOutput();

      //std::cout<<"after erosion"<<std::endl<<std::flush;

      itkRGBImageType::Pointer currentTileOverlaySegmentation = itkRGBImageType::New();
      currentTileOverlaySegmentation->SetRegions(img->GetLargestPossibleRegion() );
      currentTileOverlaySegmentation->Allocate();

      itk2DIndexType idx;
      long nx = img->GetLargestPossibleRegion().GetSize(0);
      long ny = img->GetLargestPossibleRegion().GetSize(1);

      RGBPixelType overlayColor;
      overlayColor.SetRed(0);
      overlayColor.SetGreen(255);
      overlayColor.SetBlue(255);

      for (long iy = 0; iy < ny; ++iy )
        {
          idx[1] = iy;
          for (long ix = 0; ix < nx; ++ix )
            {
              idx[0] = ix;

              currentTileOverlaySegmentation->SetPixel(idx, img->GetPixel(idx));

              if (0 == erodeMask->GetPixel(idx) && 1 == binaryMask->GetPixel(idx))
                {
                  currentTileOverlaySegmentation->SetPixel(idx, overlayColor);
                }
            }
        }

      return currentTileOverlaySegmentation;
    }
  }
}// namespace


#endif
