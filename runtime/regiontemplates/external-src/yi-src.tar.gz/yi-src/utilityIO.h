#ifndef utilitiesIO_h_
#define utilitiesIO_h_


#include <string>

// itk
#include "itkImage.h"
#include "itkImageFileWriter.h"


namespace ImagenomicAnalytics
{
  namespace IO
  {
    //--------------------------------------------------------------------------------
    // writeImage
    template< typename itkImage_t > void writeImage(typename itkImage_t::Pointer img, const char *fileName, bool compress)
    {
      typedef itk::ImageFileWriter< itkImage_t > WriterType;

      typename WriterType::Pointer writer = WriterType::New();
      writer->SetFileName( fileName );
      writer->SetInput(img);
      if (compress)
        {
          writer->UseCompressionOn();
        }
      else
        {
          writer->UseCompressionOff();
        }

      try
        {
          writer->Update();
        }
      catch ( itk::ExceptionObject &err)
        {
          std::cout << "ExceptionObject caught !" << std::endl;
          std::cout << err << std::endl;
          raise(SIGABRT);
        }
    }
    //================================================================================

  }

}// namespace


#endif
