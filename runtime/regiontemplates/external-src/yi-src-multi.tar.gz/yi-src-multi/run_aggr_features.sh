#!/bin/bash

mainAggregateFeatures.py "$@" 
