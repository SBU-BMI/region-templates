#!/bin/bash

mainSegmentFeatures -t wsi "$@" 
