#!/bin/bash

mainSegmentFeatures -t onetile "$@"
