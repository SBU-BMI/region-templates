#!/bin/bash

mainSegmentFeatures -t img "$@"
